import type ThreeView from "@navara/three";
import {
  EffectLayerDeclaration,
  type EffectLayerConfig,
  type EffectLayerUpdate,
  type ViewContext,
} from "@navara/three";

import { ToneMapping, type ToneMappingOptions } from "./toneMapping";

type LayerDescription = {
  toneMapping?: Omit<ToneMappingOptions, "enabled">;
};

export type ToneMappingConfig = LayerDescription & EffectLayerConfig;

export type ToneMappingUpdate = LayerDescription & EffectLayerUpdate;

export class ToneMappingEffectLayer extends EffectLayerDeclaration<
  ToneMappingConfig,
  ToneMappingUpdate,
  ToneMapping
> {
  static key = "toneMapping";
  static insertBefore = ["final"];

  private config: ToneMappingConfig;

  constructor(view: ThreeView, ctx: ViewContext, config: ToneMappingConfig) {
    super(view, ctx, config);
    this.config = config;
  }

  createPass() {
    const pass = new ToneMapping(this.view.camera.raw, {
      ...this.config.toneMapping,
      enabled: this.config.visible ?? true,
    });

    return pass;
  }

  onUpdateConfig(updates: ToneMappingUpdate): void {
    super.onUpdateConfig(updates);

    if (!this._instance) return;
    Object.assign(this.config, updates);

    const config = updates.toneMapping;
    if (!config) return;

    if (config.mode !== undefined) {
      this._instance.mode = config.mode;
    }
  }
}
