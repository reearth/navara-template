import type ThreeView from "@navara/three";
import {
  EffectLayerDeclaration,
  type EffectLayerConfig,
  type EffectLayerUpdate,
  type ViewContext,
} from "@navara/three";

import { SMAA, type AntialiasOptions } from "./aa";

type LayerDescription = {
  smaa?: Omit<AntialiasOptions, "enabled">;
};

export type SMAAConfig = LayerDescription & EffectLayerConfig;

export type SMAAUpdate = LayerDescription & EffectLayerUpdate;

export class SMAAEffectLayer extends EffectLayerDeclaration<
  SMAAConfig,
  SMAAUpdate,
  SMAA
> {
  static key = "smaa";
  static insertBefore = ["final"];

  private config: SMAAConfig;

  constructor(view: ThreeView, ctx: ViewContext, config: SMAAConfig) {
    super(view, ctx, config);
    this.config = config;
  }

  createPass() {
    const pass = new SMAA(this.view.camera.raw, {
      ...this.config.smaa,
      enabled: this.config.visible ?? true,
    });

    return pass;
  }

  onUpdateConfig(updates: SMAAUpdate): void {
    super.onUpdateConfig(updates);

    if (!this._instance) return;
    Object.assign(this.config, updates);

    const config = updates.smaa;
    if (!config) return;

    if (config.quality !== undefined) {
      this._instance.quality = config.quality;
    }
    if (config.edgeDetectionMode !== undefined) {
      this._instance.edgeDetectionMode = config.edgeDetectionMode;
    }
  }
}
